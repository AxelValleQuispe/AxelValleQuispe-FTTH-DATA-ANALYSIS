import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from scipy import stats

cli = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Clientes\2026-10.csv",dtype='str')
cli['PUERTO_PON'] = cli['OLT'] + "_" + cli['PUERTO_PON']

cli = cli[['ACCESS_ID','OLT','PUERTO_PON']]

planta = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Planta FTTH\planta_ftth_dic25.txt",sep='|',encoding='unicode-escape',dtype=str)

planta = planta[['ACCESS_ID','ESTADO','DNI']]
planta['TIPO_CL'] = '?'
planta['TIPO_CL'] = np.where(planta['DNI'].str.len()==8,'B2C',planta['TIPO_CL'])
planta['TIPO_CL'] = np.where(planta['DNI'].str.len()==12,'B2B',planta['TIPO_CL'])
planta = planta.drop_duplicates(subset='ACCESS_ID')

#dir_path = r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\RX_POWER_DS"
dir_path = r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Volcado global GPON"

res = os.listdir(dir_path)
print(res)
res = [x for x in res if x != 'desktop.ini']
fechas = [s.replace('.csv','') for s in res]

fechas = fechas[-7:]

pot = pd.DataFrame()
bip8 = pd.DataFrame()
rone = pd.DataFrame()

for f in fechas:
    a = pd.read_csv(dir_path+"/"+f+".csv",dtype={'LINE_ID':str})

    a['puerto'] = a['DSLAM'] + "_" + a['PORT'].str.split(pat="#",expand=True)[0]

    a1 = a[['LINE_ID','puerto','RX_POWER_DS']]
    a1.columns = ['ACCESS_ID','PUERTO_PON','POTENCIA']

    a2 = a[['LINE_ID','puerto','DS_BIP8_ERROR_RAW','US_BIP8_ERROR_RAW']]
    a2.columns = ['ACCESS_ID','PUERTO_PON','BIP8_DS','BIP8_US']
    a2['BIP8_TOTAL'] = a2['BIP8_DS'] + a2['BIP8_US']

    a3 = a[['LINE_ID','HIGH_LEVEL_ACTION']]
    a3.columns = ['ACCESS_ID','HLA']
    a3['ROGUE_ONE'] = np.where(a3['HLA']=='ONT fallida',1,0)

    pot = pd.concat([pot,a1],ignore_index=True)
    pot = pot.drop_duplicates(subset='ACCESS_ID',keep='last')

    bip8 = pd.concat([bip8,a2],ignore_index=True)
    
    rone = pd.concat([rone,a3],ignore_index=True)

    print(a)

a = pd.DataFrame()

bip8 = pd.pivot_table(bip8,index='ACCESS_ID',values='BIP8_TOTAL',aggfunc='sum').reset_index()
bip8['CLI_BIP8'] = np.where(bip8['BIP8_TOTAL']>0,1,0)

rone = pd.pivot_table(rone,index='ACCESS_ID',values='ROGUE_ONE',aggfunc='sum').reset_index()

#####

ave = pd.read_excel(r"D:\Downloads\averias_broadband_2026.xlsx",dtype={'ACCESS_ID':str})

ultd = (ave['FECHA'].drop_duplicates()).to_list()
ultd = ultd[-7:]

ave = ave[ave['FECHA'].isin(ultd)]

ave = pd.pivot_table(ave,index='ACCESS_ID',values=['IND','MAS','TOTAL'],aggfunc='sum').reset_index()

#####

periodos = ['202602','202603']

sems = ['202609','202610']

total = pd.DataFrame()

for p in periodos:

    tdp = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_"+p+"_tdp.csv",dtype=str)
    tdp['PUERTO_PON'] = tdp['OLT'] + "_" + tdp['PUERTO_PON'].str.split(pat="-",n=1,expand=True)[1]

    pan = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_"+p+"_pangea.csv",dtype=str)
    pan['PUERTO_PON'] = pan['OLT'] + "_" + pan['PUERTO_PON']

    tdp = pd.concat([tdp,pan],ignore_index=True)

    tdp['ACCESS_ID'] = tdp['ACCESS_ID'].str.replace('.0','')

    tdp = tdp[~tdp['PUERTO'].isnull()]
    
    tdp['SEMANA'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().week).astype(int)
    tdp['ANIO'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().year).astype(int)
    tdp['FECHA'] = pd.to_datetime(tdp['FECHA_INICIO']).dt.date

    tdp['PERIODO'] = np.where(tdp['SEMANA']<10,tdp['ANIO'].astype(str)+"0"+tdp['SEMANA'].astype(str),tdp['ANIO'].astype(str)+tdp['SEMANA'].astype(str))

    tdp = tdp[tdp['PERIODO'].isin(sems)]

    tdp['ALARMA'] = tdp['ALARMA'].str.upper()

    tdp['SDG'] = np.where(tdp['ALARMA'].str.find("DYING")==-1,1,0)

    print(tdp)

    total = pd.concat([total,tdp],ignore_index=True)

sempas = total[total['PERIODO']==sems[1]]
total = total[total['PERIODO']==sems[0]]

sempas = pd.pivot_table(sempas,index=['ACCESS_ID','PUERTO_PON'],values='SDG',aggfunc='sum').reset_index()
sempas = sempas.rename(columns={'SDG':'SDG_SEM_ANT'})

sdg = pd.pivot_table(total,index=['ACCESS_ID','PUERTO_PON'],values=['ALARMA','SDG'],aggfunc={'ALARMA':'count','SDG':'sum'}).reset_index()
fal = pd.pivot_table(total[total['SDG']>0],index='ACCESS_ID',values='FECHA',aggfunc=pd.Series.nunique).reset_index()

total = sdg.merge(fal,on='ACCESS_ID')
total = total.merge(sempas,on=['ACCESS_ID','PUERTO_PON'])

print(total)

#####

#pot = pot.drop(columns=['PUERTO_PON'])

pot['OLT'] = pot['PUERTO_PON'].str.rsplit(pat='_',n=1,expand=True)[0]
pot['PUERTO_PON'] = pot['OLT'] +"_"+ pot['PUERTO_PON'].str.rsplit(pat='-',n=2,expand=True)[1] +"-"+ pot['PUERTO_PON'].str.rsplit(pat='-',n=1,expand=True)[1]

pot['<=-23'] = np.where(pot['POTENCIA'] <= -23,1,0)
pot['<=-25'] = np.where(pot['POTENCIA'] <= -25,1,0)
pot['<=-28'] = np.where(pot['POTENCIA'] <= -28,1,0)

pot = pot.merge(bip8,on='ACCESS_ID',how='left')
pot = pot.merge(rone,on='ACCESS_ID',how='left')
pot = pot.merge(total,on=['ACCESS_ID','PUERTO_PON'],how='outer')
pot = pot.merge(planta,on='ACCESS_ID',how='left')
pot = pot.merge(ave,on='ACCESS_ID',how='left')
#pot = pot.merge(cli,on='ACCESS_ID',how='left')
pot['OLT'] = pot['PUERTO_PON'].str.rsplit(pat='_',n=1,expand=True)[0]

pot.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\rep_pot_bip8_alarm_mas.csv",index=False)

print(pot)