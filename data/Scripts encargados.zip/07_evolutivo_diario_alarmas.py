import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from scipy.stats import mode

periodos = ['202602','202603']

pfecha = periodos[0][:4] + "-" + periodos[0][4:] + "-01"

print(pfecha)

total = pd.DataFrame()

for p in periodos:

    tdp = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_"+p+"_tdp.csv",dtype={'ACCESS_ID':str,'PUERTO':str})
    tdp = tdp[~tdp['FECHA_INICIO'].isnull()]
    tdp['PUERTO_PON'] = tdp['OLT'] + "_" + tdp['PUERTO_PON'].str.split(pat="-",n=1,expand=True)[1]

    try:

        pan = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_"+p+"_pangea.csv",dtype={'ACCESS_ID':str,'PUERTO':str})
        pan = pan[~pan['FECHA_INICIO'].isnull()]
        pan['PUERTO_PON'] = pan['OLT'] + "_" + pan['PUERTO_PON']

        tdp = pd.concat([tdp,pan],ignore_index=True)

    except Exception as ex:
        print(ex)

    tdp['SEMANA'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().week).astype(int)
    tdp['ANIO'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().year).astype(int)
    tdp['FECHA'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.date).astype(str)

    tdp = tdp[tdp['FECHA']>=pfecha]

    tdp['PERIODO'] = np.where(tdp['SEMANA']<10,tdp['ANIO'].astype(str)+"0"+tdp['SEMANA'].astype(str),tdp['ANIO'].astype(str)+tdp['SEMANA'].astype(str))

    tdp['ALARMA'] = tdp['ALARMA'].str.upper()

    tdp['SDG'] = np.where(tdp['ALARMA'].str.find("DYING")==-1,1,0)

    print(tdp)

    total = pd.concat([total,tdp],ignore_index=True)

###### SOLO DESCOMENTAR PARA VER ALARMAS TEMPORALES / ENTRE SEMANA - PARA COMENTAR ES CTRL + K + C / PARA DESCOMENTAR ES CTRL + K + U

# try:

#    tdp = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_"+p+"_tdp_temp.csv",dtype={'ACCESS_ID':str,'PUERTO':str})
#    tdp = tdp[~tdp['FECHA_INICIO'].isnull()]
#    tdp['PUERTO_PON'] = tdp['OLT'] + "_" + tdp['PUERTO_PON'].str.split(pat="-",n=1,expand=True)[1]

#    tdp['SEMANA'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().week).astype(int)
#    tdp['ANIO'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().year).astype(int)
#    tdp['FECHA'] = pd.to_datetime(tdp['FECHA_INICIO']).dt.date

#    tdp['PERIODO'] = np.where(tdp['SEMANA']<10,tdp['ANIO'].astype(str)+"0"+tdp['SEMANA'].astype(str),tdp['ANIO'].astype(str)+tdp['SEMANA'].astype(str))

#    tdp['ALARMA'] = tdp['ALARMA'].str.upper()

#    tdp['SDG'] = np.where(tdp['ALARMA'].str.find("DYING")==-1,1,0)

#    print(tdp)

#    total = pd.concat([total,tdp],ignore_index=True)

# except Exception as ex:
#    print(ex)

######

total['OLT'] = total['PUERTO_PON'].str.rsplit(pat='_',n=1,expand=True)[0]
total = total[~total['OLT'].isnull()]

total.to_csv("D:/Downloads/evo_ratio_alarmas_puerto_total_diario.csv",index=False)

print(total)