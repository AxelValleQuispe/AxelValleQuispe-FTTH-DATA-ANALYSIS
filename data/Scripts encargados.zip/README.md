# Automatización y análisis de datos FTTH/GPON — versión anonimizada

Colección de scripts Python orientados a automatización, consolidación y análisis de
información operativa de redes FTTH/GPON.

## Contenido

- Consolidación de archivos de potencia y métricas GPON.
- Generación de reportes de atenuación/degradación.
- Consolidación de información de clientes FTTH.
- Procesamiento y consolidación de alarmas.
- Análisis de alarmas masivas y métricas BIP8.
- Evolutivos diarios, semanales y mensuales.
- Preparación de información para análisis y tableros.

## Privacidad

Esta versión fue preparada para publicación en GitHub:
- Se eliminaron nombres personales y referencias directas a la empresa.
- Se reemplazaron rutas locales/OneDrive por rutas genéricas bajo `data/`.
- Las etiquetas internas de zonas fueron sustituidas por `ZONA_A` y `ZONA_B`.
- No se incluyen archivos de datos operativos reales.

> Los archivos de entrada y salida reales no deben subirse al repositorio si contienen
> información de clientes, identificadores de red, IPs, credenciales u otra información
> confidencial.

## Estructura sugerida

```text
.
├── data/       # Datos de ejemplo o archivos de entrada no sensibles
├── output/     # Resultados generados por los scripts
├── *.py        # Scripts de automatización y análisis
├── README.md
└── .gitignore
```

## Requisitos

Python 3.10+ recomendado.

Dependencias principales:

```bash
pip install pandas numpy scipy openpyxl
```

## Nota

Los scripts conservan la lógica general del código original, pero las rutas y nombres
internos fueron generalizados para convertirlos en material demostrativo/portfolio.
