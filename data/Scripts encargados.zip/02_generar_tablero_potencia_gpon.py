import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from scipy import stats

def mode(x):
    return stats.mode(x, axis=None)[0]

dir_path = r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\RX_POWER_DS"

res = os.listdir(dir_path)
print(res)

fechas = [s.replace('.csv','') for s in res]
fechas = [x for x in fechas if x != 'desktop.ini']

prom = pd.DataFrame()
c = 0

fechas = fechas[-30:]
print(fechas)

prep = pd.DataFrame(columns=['LINE_ID','PUERTO','POTENCIA','FECHA'])

urep = pd.read_csv(dir_path+"/"+fechas[-1]+".csv",dtype={'LINE_ID':str})
urep['LINE_ID'] = urep['LINE_ID'].str.replace(".0","")

####

plat = pd.pivot_table(urep,index=['puerto'],values='RX_POWER_DS',aggfunc=['max','min',np.median,'count'])
plat.columns = ['max','min','median','count']
plat = plat.reset_index()

print(plat)

plat = plat.merge(urep[['puerto','LINE_ID']].drop_duplicates(subset='puerto'),on='puerto',how='left')

plat['DIF_MAX_MIN'] = plat['max'] - plat['min']

platt = pd.DataFrame()

bip8 = pd.DataFrame()

for fecha in fechas[-7:]:

    print(fecha)
    
    archivo = pd.read_csv(dir_path+"/"+fecha+".csv",dtype={'LINE_ID':str})
    archivo['LINE_ID'] = archivo['LINE_ID'].str.replace(".0","")
    archivo = pd.pivot_table(archivo,index=['puerto'],values='RX_POWER_DS',aggfunc=['max','min',np.median])
    archivo.columns = ['max','min','median']
    archivo = archivo.reset_index()
    archivo['DIF_MAX_MIN'] = archivo['max'] - archivo['min']
    platt = pd.concat([platt,archivo],ignore_index=True)

platt = pd.pivot_table(platt,index='puerto',values=['DIF_MAX_MIN','median'],aggfunc='mean').reset_index()
platt.columns = ['puerto','DIF_MAX_MIN_PROM','median_PROM']

plat = plat.merge(platt,on='puerto',how='left')

plat.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\rep_aten_degrad_plataformas.csv",index=False)

print(plat)

####

ctotales = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Volcado global GPON"+"/"+fechas[-1]+".csv",dtype={'LINE_ID':str},usecols=[0,1,3,9])

urep['DIAS_RECUR_DEGRAD'] = 0
urep['DIAS_DEGRAD'] = 0
urep['CANT_ATEN'] = 0

atenua = pd.DataFrame()
totpe = pd.DataFrame()

for fecha in fechas:

    print(fecha)
    
    archivo = pd.read_csv(dir_path+"/"+fecha+".csv",dtype={'LINE_ID':str})
    archivo['LINE_ID'] = archivo['LINE_ID'].str.replace(".0","")
    archivo = archivo[archivo['RX_POWER_DS']<0]
    archivo = archivo[['LINE_ID','puerto','RX_POWER_DS','Fecha']]
    archivo.columns = ['LINE_ID','PUERTO','POTENCIA','FECHA']

    #archivo = archivo[archivo['LINE_ID']=='1054455016']

    prep = pd.concat([prep,archivo[~archivo['LINE_ID'].isin(prep['LINE_ID'])]],ignore_index=True)
    #print(prep)

    archdegrad = archivo[archivo.columns]

    archdegrad['ZONA'] = np.where(archdegrad['PUERTO'].str.find("P_")!=-1,"ZONA_B","ZONA_A")
    archdegrad['UMBRAL'] = np.where(((archdegrad['ZONA']=="ZONA_B")&(archdegrad['POTENCIA']<=-25))|((archdegrad['ZONA']=="ZONA_A")&(archdegrad['POTENCIA']<=-25)),1,0)
    archdegrad = archdegrad[archdegrad['UMBRAL']==1]
    archdegrad = archdegrad.drop(columns=['ZONA','UMBRAL'])

    urep['DIAS_DEGRAD'] = np.where(urep['LINE_ID'].isin(archdegrad['LINE_ID']),urep['DIAS_DEGRAD']+1,urep['DIAS_DEGRAD'])
    urep['DIAS_RECUR_DEGRAD'] = np.where(urep['LINE_ID'].isin(archdegrad['LINE_ID']),urep['DIAS_RECUR_DEGRAD']+1,0)

    if fechas[0] != fecha:
        anterior.columns = ['LINE_ID','POT_ANT']
        anterior['FECHA_ANT'] = fechas[c-1]

        archivo = archivo.merge(anterior,on=['LINE_ID'],how='left')

        archivo['VAL'] = np.where(archivo['POTENCIA']<=archivo['POT_ANT']-2,'PEOR','IGUAL')
        archivo['VAL'] = np.where(archivo['POTENCIA']>=archivo['POT_ANT']+2,'MEJOR',archivo['VAL'])

        peores = archivo[archivo['VAL']=='PEOR']

        totpe = pd.concat([totpe,peores],ignore_index=True)

        atenua = pd.concat([atenua,peores],ignore_index=True)
        atenua = atenua.drop_duplicates(subset='LINE_ID',keep='first')

        peores = peores[['LINE_ID','POTENCIA']]
        peores.columns = ['LINE_ID','POT_PEOR']

        mejores = archivo[archivo['VAL']=='MEJOR']
        mejores = mejores[['LINE_ID','POTENCIA']]
        mejores.columns = ['LINE_ID','POT_MEJOR']

        atenua = atenua.merge(mejores,on='LINE_ID',how='left')
        atenua['POT_MEJOR'] = np.where(atenua['POT_MEJOR'].isnull(),atenua['POTENCIA'],atenua['POT_MEJOR'])
        atenua = atenua[atenua['POT_MEJOR']<=atenua['POT_ANT']-2]
        atenua = atenua.drop(columns='POT_MEJOR')

        #urep['DIAS_RECUR_DEGRAD'] = np.where(urep['LINE_ID'].isin(archdegrad['LINE_ID']),urep['DIAS_DEGRAD']+1,0)
        urep['CANT_ATEN'] = np.where(urep['LINE_ID'].isin(peores['LINE_ID']),urep['CANT_ATEN']+1,urep['CANT_ATEN'])

    print(archivo)
    c+=1
    anterior = archivo[['LINE_ID','POTENCIA']]

ttotpe = totpe[['LINE_ID','FECHA']].drop_duplicates(subset='LINE_ID',keep='last')

totpe = pd.pivot_table(totpe,index=['LINE_ID','PUERTO'],values=['FECHA','POTENCIA'],aggfunc={'FECHA':'count','POTENCIA':'min'}).reset_index()
totpe = totpe.rename(columns={'FECHA':'CAIDAS'})

totpe = totpe.merge(ttotpe,on='LINE_ID',how='left')

totpe.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\rep_caidas_cl.csv",index=False)

print(urep)
atenua.columns = atenua.columns + "_ATEN"
atenua = atenua.rename(columns={'LINE_ID_ATEN':'LINE_ID'})

print(atenua)

urep = urep.merge(atenua,on='LINE_ID',how='left')
urep['CL_DEGRAD'] = np.where(urep['DIAS_RECUR_DEGRAD']>0,1,0)
urep['CL_ATENUA'] = np.where(~urep['VAL_ATEN'].isnull(),1,0)

print(urep)

prep.columns = prep.columns + "_PDIA"
prep = prep.rename(columns={'LINE_ID_PDIA':'LINE_ID'})
urep = urep.merge(prep,on='LINE_ID',how='left')
urep['CL_ATENUA'] = np.where(urep['RX_POWER_DS']<=urep['POTENCIA_PDIA']-2,urep['CL_ATENUA'],0)

#####

cli_tot = pd.pivot_table(urep,index='puerto',values='LINE_ID',aggfunc='count').reset_index()
cli_tot.columns = ['puerto','CL_TOTALES']

urep = urep[(urep['CL_DEGRAD']==1)|(urep['CL_ATENUA']==1)]

cdegrad = urep[urep.columns]

urep.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\rep_aten_degrad_cl.csv",index=False)

pivot = pd.pivot_table(urep,index='puerto',values=['CL_DEGRAD','CL_ATENUA'],aggfunc='sum').reset_index()

aa = pivot[pivot['CL_DEGRAD']==0]
dd = pivot[pivot['CL_ATENUA']==0]
ad = pivot[(pivot['CL_ATENUA']>0)&(pivot['CL_DEGRAD']>0)]

aa = urep[urep['puerto'].isin(aa['puerto'])]
aa = pd.pivot_table(aa,index=['puerto','Fecha'],values=['LINE_ID','RX_POWER_DS','RX_POWER_US','CANT_ATEN','POT_ANT_ATEN'],aggfunc={'LINE_ID':'count','RX_POWER_DS':'min','RX_POWER_US':'min','CANT_ATEN':'max','POT_ANT_ATEN':'min'}).reset_index()
aa['TIPO'] = "ATENUADO"

dd = urep[urep['puerto'].isin(dd['puerto'])]
dd = pd.pivot_table(dd,index=['puerto','Fecha'],values=['LINE_ID','RX_POWER_DS','RX_POWER_US','DIAS_RECUR_DEGRAD','DIAS_DEGRAD'],aggfunc={'LINE_ID':'count','RX_POWER_DS':'min','RX_POWER_US':'min','DIAS_RECUR_DEGRAD':'max','DIAS_DEGRAD':'max'}).reset_index()
dd['TIPO'] = "DEGRADADO"

ad = urep[urep['puerto'].isin(ad['puerto'])]
ad = pd.pivot_table(ad,index=['puerto','Fecha'],values=['LINE_ID','RX_POWER_DS','RX_POWER_US','DIAS_RECUR_DEGRAD','DIAS_DEGRAD','CANT_ATEN','POT_ANT_ATEN'],aggfunc={'LINE_ID':'count','RX_POWER_DS':'min','RX_POWER_US':'min','DIAS_RECUR_DEGRAD':'max','DIAS_DEGRAD':'max','CANT_ATEN':'max','POT_ANT_ATEN':'min'}).reset_index()
ad['TIPO'] = "ATENUADO/DEGRADADO"

final = pd.concat([ad,aa,dd],ignore_index=True)
final = final.rename(columns={'LINE_ID':'CL_AFECTADOS'})

lnid = urep[['LINE_ID','puerto','FECHA_ANT_ATEN']].sort_values(by=['puerto','FECHA_ANT_ATEN']).drop_duplicates(subset='puerto')
final = final.merge(lnid,on='puerto',how='left')
final = final.merge(cli_tot,on='puerto',how='left')

final['CANT_ATEN'] = final['CANT_ATEN'].fillna(0)
final['POT_ANT_ATEN'] = np.where(final['POT_ANT_ATEN'].isnull(),final['RX_POWER_DS'],final['POT_ANT_ATEN'])
final['FECHA_ANT_ATEN'] = np.where(final['FECHA_ANT_ATEN'].isnull(),pd.to_datetime(pd.to_datetime(final['Fecha']) - pd.to_timedelta(final['DIAS_RECUR_DEGRAD'],unit='days')).dt.date,final['FECHA_ANT_ATEN'])
final['AFECTACION'] = np.where(final['CL_AFECTADOS']==1,"INDIVIDUAL","PARCIAL")
final['AFECTACION'] = np.where(final['CL_AFECTADOS']>=((2/3)*final['CL_TOTALES']),"TOTAL",final['AFECTACION'])

final['DIF_POT'] = final['RX_POWER_DS'] - final['POT_ANT_ATEN']
final['DIAS_AFECTACION'] = (pd.to_datetime(final['Fecha'])-pd.to_datetime(final['FECHA_ANT_ATEN'])).dt.days
final['Fecha'] = pd.to_datetime(final['Fecha']).dt.date
final['FECHA_ANT_ATEN'] = pd.to_datetime(final['FECHA_ANT_ATEN']).dt.date

final['ZONA'] = np.where(final['puerto'].str.find('P_')!=-1,"ZONA_B","ZONA_A")

final.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\rep_aten_degrad.csv",index=False)

#######

ctotales['FECHA'] = (pd.to_datetime(ctotales['ESTIMATION_DATE']).dt.date).astype('str')
ctotales['PUERTO'] = ctotales['DSLAM'] +'_'+ctotales['PORT'].str.split(pat='#',expand=True)[0]
ctotales['ONU'] = ctotales['PORT'].str.split(pat='#',expand=True)[1]

onuid = ctotales[['LINE_ID','ONU']]

ctotales = pd.pivot_table(ctotales,index=['PUERTO','FECHA'],values='LINE_ID',aggfunc='count').reset_index()
ctotales.columns = ['PUERTO','FECHA','CL_TOTALES']

cdegrad = cdegrad.rename(columns={'puerto':'PUERTO'})
cdegrad['CL_CRITICOS'] = 0
cdegrad['CL_CRITICOS'] = np.where((cdegrad['PUERTO'].str.find('P_')!=-1)&(cdegrad['RX_POWER_DS']<=-21),1,cdegrad['CL_CRITICOS'])
cdegrad['CL_CRITICOS'] = np.where((cdegrad['PUERTO'].str.find('P_')==-1)&(cdegrad['RX_POWER_DS']<=-25),1,cdegrad['CL_CRITICOS'])

cdegrad = cdegrad[cdegrad['CL_CRITICOS']>0]

cddegrad = cdegrad[['LINE_ID','PUERTO','RX_POWER_DS']]
cddegrad = cddegrad.sort_values(by='RX_POWER_DS',ascending=True)
cddegrad = cddegrad.drop_duplicates(subset='PUERTO',keep='first')

cdegrad= pd.pivot_table(cdegrad,index=['PUERTO'],values=['CL_CRITICOS'],aggfunc='sum').reset_index()

cdegrad = cdegrad.merge(ctotales,on='PUERTO',how='left')
cdegrad = cdegrad.merge(cddegrad,on='PUERTO',how='left')
cdegrad = cdegrad.merge(onuid,on='LINE_ID',how='left')

cdegrad['RATIO'] = cdegrad['CL_CRITICOS'] / cdegrad['CL_TOTALES']
cdegrad['ZONA'] = np.where(cdegrad['PUERTO'].str.find('P_')!=-1,"ZONA_B","ZONA_A")

# cdegrad = cdegrad[cdegrad['CL_CRITICOS']>=5]
# cdegrad = cdegrad[cdegrad['RATIO']>=0.3]

cdegrad['OLT'] = cdegrad['PUERTO'].str.rsplit(pat='_',n=1,expand=True)[0]

dpto = pd.read_excel(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Descargas Backup\olt_x_dpto_ftth.xlsx",sheet_name='OLTxDPTO')
dpto = dpto[dpto.columns[:5]]
dpto = dpto.drop(columns=['ZONA'])

reg = pd.read_excel(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Descargas Backup\olt_x_dpto_ftth.xlsx",sheet_name='DPTOxREGION')

cdegrad = cdegrad.merge(dpto,on='OLT',how='left')
cdegrad = cdegrad.merge(reg,on='DPTO',how='left')

cdegrad.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\rep_aten_degrad_nuevo_filtro.csv",index=False)