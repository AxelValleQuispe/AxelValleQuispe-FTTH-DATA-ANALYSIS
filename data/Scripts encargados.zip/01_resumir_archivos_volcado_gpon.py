import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import os


dir_path= r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\RX_POWER_DS"
res = os.listdir(dir_path)
res = [s.replace('.csv','') for s in res]
res = [x for x in res if x != 'desktop.ini']

val = res[-1]
print(val)

dir_path = r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Volcado global GPON"

res = os.listdir(dir_path)
print(res)

fechas = [s.replace('.csv','') for s in res]
fechas = [x for x in fechas if x != 'desktop.ini']
fechas = [x for x in fechas if x > val]

#fechas = fechas[-35:]

prom = pd.DataFrame()
c = 0

for fecha in fechas:

    print(fecha)
    
    archivo = pd.read_csv(dir_path+"/"+fecha+".csv",dtype={'LINE_ID':str})
    archivo['puerto'] = archivo['DSLAM'] +'_'+archivo['PORT'].str.split(pat='#',expand=True)[0]
    archivo = archivo[archivo['LINK_STATE_DESCRIPTION']=='En servicio']
    #archivo = archivo[archivo['RX_POWER_DS']!=0]

    archivo = archivo[['LINE_ID','puerto','RX_POWER_DS','RX_POWER_US','TX_POWER_DS','TX_POWER_US','DS_BIP8_ERROR_RAW','US_BIP8_ERROR_RAW']]
    archivo['RX_POWER_DS'] = np.trunc(archivo['RX_POWER_DS'])
    archivo['RX_POWER_US'] = np.trunc(archivo['RX_POWER_US'])
    archivo['TX_POWER_DS'] = np.trunc(archivo['TX_POWER_DS'])
    archivo['TX_POWER_US'] = np.trunc(archivo['TX_POWER_US'])
    archivo['Fecha'] = fecha

    archivo.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - GPON\RX_POWER_DS"+"/"+fecha+".csv",index=False)