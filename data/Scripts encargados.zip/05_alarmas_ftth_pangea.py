import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from scipy.stats import mode
import pathlib

archivos = []

def list_files_walk(n):
    for root, dirs, files in os.walk(n):
        for file in files:
            print(os.path.join(root, file))
            a = str(os.path.join(root, file))
            if a.find("Alarmas_ONU") != -1:
                archivos.append(a)

list_files_walk(r"D:\Downloads\alarmas_pangea")
print(archivos)

onu_p = pd.DataFrame()

for r in archivos:
    print(r)
    a = pd.read_csv(r,dtype=str)
    a.columns = a.columns.str.upper()

    a['VNO_CODE'] = a['VNO_CODE'].str.replace('.0','')

    try:
        #a = a.rename(columns={'ALARMNAME':'ALARMA'})
        a['ALARMA'] = np.where(a['ALARMA'].str.find('ENERGIA')!=-1,'DYING-GASP',a['ALARMA'])
    except:
        print("No existe la columna")

    #a = a[a['ALARMA'].str.find('Dying')!=-1]

    print(a)

    a['PUERTO_P'] = a['SLOT'].astype('str')+"-"+a['PUERTO'].astype('str')+"#"+a['ONU_ID'].astype('str')
    a['PUERTO_PON'] = a['SLOT'].astype('str')+"-"+a['PUERTO'].astype('str')

    a = a[['ALARMA','OLT','TIME_INICIO','TIME_CIERRE','PUERTO_P','PUERTO_PON','TECNOLOGIA','VNO_CODE']]

    print(a.columns)

    a.columns = ['ALARMA','OLT','FECHA_INICIO','FECHA_CIERRE','PUERTO','PUERTO_PON','MARCA','ACCESS_ID']

    print(a.columns)

    a['FECHA_INICIO'] = pd.to_datetime(a['FECHA_INICIO'],dayfirst=True,format='mixed')
    a['FECHA_CIERRE'] = pd.to_datetime(a['FECHA_CIERRE'],dayfirst=True,format='mixed')
    a['DURACION'] = a['FECHA_CIERRE'] - a['FECHA_INICIO']

    a['ZONA'] = 'ZONA_B'

    print(a)
    onu_p = pd.concat([onu_p,a],ignore_index=True)

# rep = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_202603_pangea.csv",dtype=str)

# onu_p = pd.concat([rep,onu_p],ignore_index=True)

onu_p['ACCESS_ID'] = onu_p['ACCESS_ID'].str.replace(".0","")

onu_p.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_202603_pangea.csv",index=False)

print(onu_p)