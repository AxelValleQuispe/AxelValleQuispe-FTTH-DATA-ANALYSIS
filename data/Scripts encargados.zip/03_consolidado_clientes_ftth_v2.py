import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from scipy import stats

### Cuenta de semanas para procesar (S-1)
semanas = 1
###

for n in reversed(range(semanas)):

    d = datetime.today() - timedelta(days=(n*7))

    sem = d.isocalendar().week

    anio = d.isocalendar().year

    #anio = '2024'
    s = [sem]

    for sem in s:

        print(str(anio)+"-"+str(sem))

        if(sem > 10):
            semm = str(sem-1)
        else:
            semm = "0"+str(sem-1)
            
        print(semm)

        archivos = []

        def list_files_walk(n):
            for root, dirs, files in os.walk(n+"\\"+str(anio)+"\\"+semm):
                for file in files:
                    print(os.path.join(root, file))
                    a = str(os.path.join(root, file))
                    archivos.append(a)

        list_files_walk(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - CLIENTES FTTH\PLATAFORMA")

        print(archivos)

        hua = pd.read_excel([x for x in archivos if x.find('Huaw')!=-1][0],dtype={'Alias':str})
        hua = hua[['Alias','SERIALNUMBER','Device Name','Slot','Port','ONU ID','Running Status']]
        hua.columns = ['ACCESS_ID','SERIALNUMBER','OLT','SLOT','PORT','ONU_ID','STATUS']
        hua = hua[hua['SERIALNUMBER'].str.find('-')==-1]
        hua = hua[hua['ONU_ID']<100]
        hua['STATUS'] = np.where(hua['STATUS']=='Online','Active','Inactive')
        hua['VENDOR'] = 'HUAWEI'
        hua['ZONA'] = 'ZONA_A'
        hua['PON Port'] = "0/" + (hua['SLOT'].astype(int)).astype(str) + "/" + (hua['PORT'].astype(int)).astype(str)
        
        print(hua)

        try:
            zte = pd.read_excel([x for x in archivos if x.find('ZTE')!=-1][0],dtype={'ONU Name':str})
            zte = zte[['ONU Name','MAC/SN','NE Name','Slot','Port','ONU ID','Operational Status']]
        except:
            zte = pd.read_excel([x for x in archivos if x.find('ZTE')!=-1][0],dtype={'Name':str})
            zte = zte[['Name','MAC/SN','NE Name','Slot','Port','ONU ID','Operational Status']]
        
        zte.columns = ['ACCESS_ID','SERIALNUMBER','OLT','SLOT','PORT','ONU_ID','STATUS']
        zte['STATUS'] = np.where(zte['STATUS']=='Online','Active','Inactive')
        zte = zte[zte['SERIALNUMBER'].str.find('-')==-1]
        zte = zte[zte['ONU_ID']<100]
        zte['VENDOR'] = 'ZTE'
        zte['ZONA'] = 'ZONA_A'
        zte['PON Port'] = "1-1-" + (zte['SLOT'].astype(int)).astype(str) + "-" + (zte['PORT'].astype(int)).astype(str)
        print(zte)

        pan = pd.read_excel([x for x in archivos if x.find('Conex')!=-1][0],dtype=str)
        pan.columns = pan.columns.str.upper()
        pan = pan[['VNO_CODE','SERIAL_NUMBER','OLT','TARJETA','PUERTO','ONU_ID','STATUS']]
        pan['VNO_CODE'] = pan['VNO_CODE'].astype(str)
        pan.columns = ['ACCESS_ID','SERIALNUMBER','OLT','SLOT','PORT','ONU_ID','STATUS']
        pan['STATUS'] = np.where(pan['STATUS'].isin(['Up','Online']),'Active','Inactive')
        pan['ACCESS_ID'] = pan['ACCESS_ID'].str.replace(".0","")
        pan['VENDOR'] = np.where(pan['OLT'].str.find("OLT_C")!=-1,"ZTE","NOKIA")
        pan['ZONA'] = 'ZONA_B'
        pan['PON Port'] = pan['SLOT'].astype('str') +'-'+ pan['PORT'].astype('str')

        print(pan)

        total = pd.concat([pan,zte,hua],ignore_index=True)

        total['PUERTO'] = total['SLOT'].astype('str')+"-"+total['PORT'].astype('str')+"#"+total['ONU_ID'].astype('str')
        total['PUERTO_PON'] = total['SLOT'].astype('str')+"-"+total['PORT'].astype('str')

        if(sem == 1):
            sem = 53
            anio = str(anio-1)

        if(sem > 10):
            sem = str(sem-1)
        else:
            sem = "0"+str(sem-1)

        anio = str(anio)

        print(anio+"-"+sem)

        tt = pd.pivot_table(total,index=['ZONA','OLT','PON Port'],values='ONU_ID',aggfunc='count').reset_index()
        tt.columns = ['ZONA','OLT Name','PON Port','ONUs']
        tt[tt['ZONA']=='ZONA_A'].drop(columns=['ZONA']).to_excel(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - FTTH\Historico"+"/"+anio+"-"+sem+".xlsx",index=False,sheet_name='FTTHxPuertos')
        tt[tt['ZONA']=='ZONA_B'].drop(columns=['ZONA']).to_excel(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - FTTH\NOC ZONA_B"+"/"+anio+"-"+sem+".xlsx",index=False)

        total = total.sort_values(by='STATUS',ascending=True)
        total = total.drop_duplicates(subset='SERIALNUMBER',keep='first')
        total = total.drop(columns=['PON Port'])

        total.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Clientes"+"/"+anio+"-"+sem+".csv",index=False)

        print(total)

    ####### FTTH HISTORICO - EVOLUTIVO SEMANAL DE CONEXIONES #######

    dir_path = r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - FTTH\Historico"
    dir_path2 = r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - FTTH\NOC ZONA_B"

    d = datetime.today() - timedelta(days=((n+1)*7))

    if d.isocalendar().week < 10:
        sem = "0"+str(d.isocalendar().week)
    else:
        sem = str(d.isocalendar().week)

    anio = str(d.isocalendar().year)

    sem = anio+"-"+sem

    print(sem)

    r = datetime.strptime(sem + '-1', "%Y-%W-%w")
    print(r)

    a = pd.DataFrame()

    anio = int(sem.split('-')[0])
    semana = int(sem.split('-')[1])

    tdp = pd.read_excel(dir_path+"/"+sem+".xlsx",sheet_name='FTTHxPuertos',engine='openpyxl')
    tdp['ZONA'] = 'ZONA_A'

    pangea = pd.read_excel(dir_path2+"/"+sem+".xlsx",engine='openpyxl')
    pangea['ZONA'] = 'ZONA_B'

    a = pd.concat([tdp,pangea],ignore_index=True)

    a['ANIO'] = anio
    a['SEMANA'] = semana
    a['FECHA'] = r

    a.columns = ['OLT','PUERTO','CLIENTES','ZONA','ANIO','SEMANA','FECHA']

    prom = a

    prom['OLT'] = prom['OLT'].str.replace('FERREÑAFE','FERRENAFE')

    # prom = prom.merge(dpto,on='OLT',how='left')
    # prom = prom.merge(region,on='DPTO',how='left')
    #prom = prom.merge(nodo,on='OLT',how='left')

    prom['FECHA'] = pd.to_datetime(prom['FECHA'])
    prom['MES'] = pd.to_datetime(prom['FECHA']).dt.month
    prom['ANIOSEM'] = np.where(prom['SEMANA']<10,prom['ANIO'].astype('str')+'0'+prom['SEMANA'].astype('str'),prom['ANIO'].astype('str')+prom['SEMANA'].astype('str'))

    prom['PUERTO_PON'] = prom['PUERTO'].str.replace("/","-")
    prom['PUERTO_PON'] = np.where(prom['PUERTO_PON'].str.count("-")>1,prom['PUERTO_PON'].str.rsplit(pat='-',n=2,expand=True)[1]+"-"+prom['PUERTO_PON'].str.rsplit(pat='-',n=1,expand=True)[1],prom['PUERTO_PON'])

    prom['PUERTO_PON_2'] = np.where(prom['OLT'].str.find("OLT_MA")!=-1,prom['OLT']+"_"+"0-"+prom['PUERTO_PON'],prom['OLT']+"_"+"1-"+prom['PUERTO_PON'])

    prom['PUERTO_PON'] = prom['OLT'] + "_" + prom['PUERTO_PON']

    prom = prom[['OLT','PUERTO','PUERTO_PON','PUERTO_PON_2','CLIENTES','ZONA','ANIO','SEMANA','FECHA','MES','ANIOSEM']]


    rep = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - FTTH\CSV\FTTH_Clientes_Historico.csv")

    rep = pd.concat([rep,prom],ignore_index=True)
    rep['FECHA'] = pd.to_datetime(rep['FECHA'])

    rep.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - FTTH\CSV\FTTH_Clientes_Historico.csv",index=False)

    print(prom)

    #####

    fsem = pd.pivot_table(rep,index=['ANIO','MES'],values='SEMANA',aggfunc='max').reset_index()
    fsem['FIN_MES'] = 'SI'

    fsem['ANIOSEM'] = np.where(fsem['SEMANA']<10,fsem['ANIO'].astype('str')+'0'+fsem['SEMANA'].astype('str'),fsem['ANIO'].astype('str')+fsem['SEMANA'].astype('str'))

    fsem.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - FTTH\CSV\sem_fin_mes.csv",index=False)
    print(fsem)