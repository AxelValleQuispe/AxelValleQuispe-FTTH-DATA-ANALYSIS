import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from scipy.stats import mode

archivos = []

def list_files_walk(n):
    for root, dirs, files in os.walk(n):
        for file in files:
            print(os.path.join(root, file))
            a = str(os.path.join(root, file))
            archivos.append(a)

list_files_walk(r"D:\Downloads\alarmas_tdp_temporal")
print(archivos)

#####

zte = [x for x in archivos if x.find('FTTH_ZTE')!=-1]
zte = [x for x in zte if x.find('.csv')!=-1]
#val = res[-1]
print(zte)

zte_t = pd.DataFrame()

for r in zte:
    print(r)
    a = pd.read_csv(r,skiprows=1,encoding='unicode-escape')
    print(a)

    a['RACK'] = (a['Location'].str.split(',',expand=True)[0]).str.split('=',expand=True)[1]
    a['SHELF'] = (a['Location'].str.split(',',expand=True)[1]).str.split('=',expand=True)[1]
    a['SLOT'] = (a['Location'].str.split(',',expand=True)[2]).str.split('=',expand=True)[1]
    a['PORT'] = (a['Location'].str.split(',',expand=True)[3]).str.split('=',expand=True)[1]
    a['ONUID'] = (a['Location'].str.split(',',expand=True)[4]).str.split('=',expand=True)[1]

    a['PUERTO'] = a['SHELF']+"-"+a['SLOT']+"-"+a['PORT']+"#"+a['ONUID']
    a['PUERTO_PON'] = a['SHELF']+"-"+a['SLOT']+"-"+a['PORT']

    a = a[['Alarm Code','NE','Raised Time','Cleared Time','PUERTO','PUERTO_PON','Remark']]
    a.columns = ['ALARMA','OLT','FECHA_INICIO','FECHA_CIERRE','PUERTO','PUERTO_PON','ACCESS_ID']

    a['ACCESS_ID'] = a['ACCESS_ID'].str.split(pat='ONU Name=',expand=True)[1]
    a['ACCESS_ID'] = np.where(a['ACCESS_ID'].str.find(',')!=-1,a['ACCESS_ID'].str.split(pat=',',n=1,expand=True)[0],a['ACCESS_ID'])

    print(a['ACCESS_ID'])

    a['FECHA_INICIO'] = pd.to_datetime(a['FECHA_INICIO'])
    a['FECHA_CIERRE'] = pd.to_datetime(a['FECHA_CIERRE'])
    a['DURACION'] = a['FECHA_CIERRE'] - a['FECHA_INICIO']

    a['MARCA'] = 'ZTE'
    a['ZONA'] = 'ZONA_A'

    print(a)
    zte_t = pd.concat([zte_t,a],ignore_index=True)

print(zte_t)

#######

hua = [x for x in archivos if x.find('FTTH_Huawe')!=-1]
#val = res[-1]
print(hua)

huawei = pd.DataFrame()

for r in hua:
    print(r)
    if r.find("_1.xlsx")!=-1:
        a = pd.read_excel(r,skiprows=5)
    else:
        a = pd.read_excel(r)

    print(a.columns)
    
    a['Frame'] = (a['Location Info'].str.split(',',expand=True)[0]).str.split('=',expand=True)[1]
    a['Slot'] = (a['Location Info'].str.split(',',expand=True)[1]).str.split('=',expand=True)[1]
    a['Subslot'] = (a['Location Info'].str.split(',',expand=True)[2]).str.split('=',expand=True)[1]
    a['Port'] = (a['Location Info'].str.split(',',expand=True)[3]).str.split('=',expand=True)[1]
    a['ONUID'] = (a['Location Info'].str.split(',',expand=True)[4]).str.split('=',expand=True)[1]

    a['PUERTO'] = a['Frame']+"-"+a['Slot']+"-"+a['Port']+"#"+a['ONUID']
    a['PUERTO_PON'] = a['Frame']+"-"+a['Slot']+"-"+a['Port']

    a = a[['Name','Alarm Source','Last Occurred (ST)','Cleared On (ST)','PUERTO','PUERTO_PON','User Label']]
    a.columns = ['ALARMA','OLT','FECHA_INICIO','FECHA_CIERRE','PUERTO','PUERTO_PON','ACCESS_ID']

    a['FECHA_INICIO'] = pd.to_datetime(a['FECHA_INICIO'])
    a['FECHA_CIERRE'] = pd.to_datetime(a['FECHA_CIERRE'])
    a['DURACION'] = a['FECHA_CIERRE'] - a['FECHA_INICIO']

    a['MARCA'] = 'HUAWEI'
    a['ZONA'] = 'ZONA_A'

    print(a)
    huawei = pd.concat([huawei,a],ignore_index=True)

print(huawei)

########

total = pd.concat([huawei,zte_t],ignore_index=True)

total.to_csv(r"D:\OneDrive - EMPRESA_DEMO\Archivos de USUARIO_DEMO - Consolidado Alarmas\alarmas_202603_tdp_temp.csv",index=False)

print(total)