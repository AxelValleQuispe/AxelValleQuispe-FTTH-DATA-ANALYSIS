import pandas as pd
import numpy as np
from datetime import date, datetime, timedelta
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows
import os
from scipy.stats import mode

cert = pd.DataFrame()

#####

lista = pd.read_excel(r"D:\Downloads\CR_TIF_ALARM_GENERAL_PTOS_TRABAJADOS_2026.xlsx",sheet_name='LISTA')

#####

cli = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\REPORTES CALIDAD FIJA\FTTH\CSV\FTTH_Clientes_Historico.csv")

cli = cli[cli['ANIO']>=2025]

clim = cli[['PUERTO_PON','ANIO','MES','CLIENTES']]
clim = clim.drop_duplicates(subset=['PUERTO_PON','ANIO','MES'],keep='last')
#clim = clim[clim['PUERTO_PON'].isin(lista['PUERTO_PON'])]

cli = cli[['PUERTO_PON','ANIO','SEMANA','CLIENTES']]

#cli = cli[cli['PUERTO_PON'].isin(lista['PUERTO_PON'])]

print(cli)

cl = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\VARIOS\Consolidado Clientes\2026-09.csv",dtype=str)

cl = cl.drop_duplicates(subset='ACCESS_ID',keep='first')

cl['PUERTO_PON'] = cl['OLT'] + "_" + cl['PUERTO_PON']

cl = cl[['ACCESS_ID','PUERTO_PON']]

#####

# ave = pd.read_excel(r"D:\Downloads\averias_broadband_2025_puerto.xlsx")

# ave['PUERTO_PON'] = ave['PUERTO_PON_2'].str.rsplit(pat='_',n=1,expand=True)[0] + "_" + ave['PUERTO_PON_2'].str.rsplit(pat='-',n=2,expand=True)[1] + "-" + ave['PUERTO_PON_2'].str.rsplit(pat='-',n=1,expand=True)[1]

ave = pd.read_excel(r"D:\Downloads\averias_broadband_2026.xlsx",dtype={'ACCESS_ID':str})

ave = ave.merge(cl,on='ACCESS_ID',how='left')

ave = pd.pivot_table(ave,index=['FECHA','PUERTO_PON'],values=['IND','MAS','TOTAL'],aggfunc='sum').reset_index()

ave = ave[pd.to_datetime(ave['FECHA']).dt.year>=2025]

ave['SEMANA'] = pd.to_datetime(ave['FECHA']).dt.isocalendar().week
ave['ANIO_ISO'] = pd.to_datetime(ave['FECHA']).dt.isocalendar().year

ave['MES'] = pd.to_datetime(ave['FECHA']).dt.month
ave['ANIO'] = pd.to_datetime(ave['FECHA']).dt.year

avem = pd.pivot_table(ave,index=['ANIO','MES','PUERTO_PON'],values=['IND','MAS','TOTAL'],aggfunc='sum').reset_index()

ave = pd.pivot_table(ave,index=['ANIO_ISO','SEMANA','PUERTO_PON'],values=['IND','MAS','TOTAL'],aggfunc='sum').reset_index()
ave = ave.rename(columns={'ANIO_ISO':'ANIO'})

print(ave)

#####

con = pd.read_csv(r"D:\Downloads\contactos_2025_FTTH.txt",sep='|',dtype={'ACCESS_ID':str,'FECHA':str})

con['SEMANA'] = pd.to_datetime(con['FECHA'],dayfirst=True).dt.isocalendar().week
con['ANIO_ISO'] = pd.to_datetime(con['FECHA'],dayfirst=True).dt.isocalendar().year

con['MES'] = pd.to_datetime(con['FECHA'],dayfirst=True).dt.month
con['ANIO'] = pd.to_datetime(con['FECHA'],dayfirst=True).dt.year

con = con.merge(cl,on='ACCESS_ID',how='left')

conm = pd.pivot_table(con,index=['ANIO','MES','PUERTO_PON'],values='CONTACTOS',aggfunc='sum').reset_index()

con = pd.pivot_table(con,index=['ANIO_ISO','SEMANA','PUERTO_PON'],values='CONTACTOS',aggfunc='sum').reset_index()
con = con.rename(columns={'ANIO_ISO':'ANIO'})

print(con)

#con.to_excel("D:/Downloads/sum_con_.xlsx",index=False)

#####

cli = cli.merge(ave,on=['ANIO','SEMANA','PUERTO_PON'],how='left')
cli = cli.merge(con,on=['ANIO','SEMANA','PUERTO_PON'],how='left')
cli = cli.merge(lista,on='PUERTO_PON',how='left')

cli['SEMANA N'] = (((cli['ANIO']-2025)*52)+cli['SEMANA']) - (((pd.to_datetime(cli['FECHA_TRABAJO']).dt.isocalendar().year - 2025)*52)+pd.to_datetime(cli['FECHA_TRABAJO']).dt.isocalendar().week)

cli.to_csv(r"D:/Downloads/evo_ratio_ave_con_puerto_total_semanal_n_1.csv",index=False)

print(cli)

#####

clim = clim.merge(avem,on=['ANIO','MES','PUERTO_PON'],how='left')
clim = clim.merge(conm,on=['ANIO','MES','PUERTO_PON'],how='left')
clim = clim.merge(lista,on='PUERTO_PON',how='left')

clim['MES N'] = (((clim['ANIO']-2025)*12)+clim['MES']) - (((pd.to_datetime(clim['FECHA_TRABAJO']).dt.year - 2025)*12)+pd.to_datetime(clim['FECHA_TRABAJO']).dt.month)

#clim['CONTSIM'] = np.where(clim['MODELO FRANCO'].isnull(),clim['CONTACTOS'],0)

clim.to_csv(r"D:/Downloads/evo_ratio_ave_con_puerto_total_mensual_n_1.csv",index=False)

print(clim)

#####

cat = pd.read_excel(r"D:\Downloads\catalogo_alarmas_onu.xlsx")
cat = cat[['ALARMA','ALARMA_UNIFICADA']]

periodos = ['202510','202511','202512','202601','202602']

pfecha = periodos[0][:4] + "-" + periodos[0][4:] + "-01"
print(pfecha)

total = pd.DataFrame()

for p in periodos:

    tdp = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\VARIOS\Consolidado Alarmas\alarmas_"+p+"_tdp.csv",dtype={'ACCESS_ID':str,'PUERTO':str})
    tdp = tdp[~tdp['PUERTO'].isnull()]
    tdp['PUERTO_PON'] = tdp['OLT'] + "_" + tdp['PUERTO_PON'].str.split(pat="-",n=1,expand=True)[1]

    try:

        pan = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\VARIOS\Consolidado Alarmas\alarmas_"+p+"_pangea.csv",dtype={'ACCESS_ID':str,'PUERTO':str})
        pan = pan[~pan['PUERTO'].isnull()]
        pan['PUERTO_PON'] = pan['OLT'] + "_" + pan['PUERTO_PON']

        tdp = pd.concat([tdp,pan],ignore_index=True)

    except Exception as ex:
        print(ex)

    #tdp = tdp[tdp['PUERTO_PON'].isin(lista['PUERTO_PON'])]

    tdp['SEMANA'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().week).astype(int)
    tdp['ANIO'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.isocalendar().year).astype(int)
    tdp['FECHA'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.date).astype(str)

    tdp = tdp[tdp['FECHA']>=pfecha]

    tdp['PERIODO'] = np.where(tdp['SEMANA']<10,tdp['ANIO'].astype(str)+"0"+tdp['SEMANA'].astype(str),tdp['ANIO'].astype(str)+tdp['SEMANA'].astype(str))

    tdp['ALARMA'] = tdp['ALARMA'].str.upper()

    tdp['SDG'] = np.where(tdp['ALARMA'].str.find("DYING")==-1,1,0)

    tdp = tdp.fillna('-')

    tdp = pd.pivot_table(tdp,index=['PERIODO','SEMANA','ANIO','PUERTO_PON'],values=['ALARMA','SDG'],aggfunc={'ALARMA':'count','SDG':'sum'}).reset_index()

    print(tdp)

    total = pd.concat([total,tdp],ignore_index=True)

######

total = pd.pivot_table(total,index=['PERIODO','SEMANA','ANIO','PUERTO_PON'],values=['ALARMA','SDG'],aggfunc={'ALARMA':'sum','SDG':'sum'}).reset_index()

print(total)

total['OLT'] = total['PUERTO_PON'].str.rsplit(pat='_',n=1,expand=True)[0]

total = total.merge(lista,on='PUERTO_PON',how='left')

total['SEMANA N'] = (((total['ANIO']-2025)*52)+total['SEMANA']) - (((pd.to_datetime(total['FECHA_TRABAJO']).dt.isocalendar().year - 2025)*52)+pd.to_datetime(total['FECHA_TRABAJO']).dt.isocalendar().week)

total.to_csv(r"D:/Downloads/evo_ratio_alarmas_puerto_total_semanal_n_1.csv",index=False)

print(total)

##################################

total = pd.DataFrame()

for p in periodos:

    tdp = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\VARIOS\Consolidado Alarmas\alarmas_"+p+"_tdp.csv",dtype={'ACCESS_ID':str,'PUERTO':str})
    tdp = tdp[~tdp['PUERTO'].isnull()]
    tdp['PUERTO_PON'] = tdp['OLT'] + "_" + tdp['PUERTO_PON'].str.split(pat="-",n=1,expand=True)[1]

    try:

        pan = pd.read_csv(r"D:\OneDrive - EMPRESA_DEMO\VARIOS\Consolidado Alarmas\alarmas_"+p+"_pangea.csv",dtype={'ACCESS_ID':str,'PUERTO':str})
        pan = pan[~pan['PUERTO'].isnull()]
        pan['PUERTO_PON'] = pan['OLT'] + "_" + pan['PUERTO_PON']

        tdp = pd.concat([tdp,pan],ignore_index=True)

    except Exception as ex:
        print(ex)

    tdp = tdp[tdp['PUERTO_PON'].isin(lista['PUERTO_PON'])]

    tdp['MES'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.month).astype(int)
    tdp['ANIO'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.year).astype(int)
    tdp['FECHA'] = (pd.to_datetime(tdp['FECHA_INICIO']).dt.date).astype(str)

    tdp = tdp[tdp['FECHA']>=pfecha]

    tdp['PERIODO'] = np.where(tdp['MES']<10,tdp['ANIO'].astype(str)+"0"+tdp['MES'].astype(str),tdp['ANIO'].astype(str)+tdp['MES'].astype(str))

    tdp['ALARMA'] = tdp['ALARMA'].str.upper()

    tdp['SDG'] = np.where(tdp['ALARMA'].str.find("DYING")==-1,1,0)

    tdp['OLT'] = tdp['PUERTO_PON'].str.rsplit(pat='_',n=1,expand=True)[0]
    tdp['PUERTO'] = tdp['OLT'] + "_" + tdp['PUERTO']

    tdp = tdp.fillna('-')

    tdp = tdp.merge(cat,on='ALARMA',how='left')

    #tdp = tdp[tdp['ALARMA_UNIFICADA']=='Degraded Signal']

    tdp = pd.pivot_table(tdp,index=['PERIODO','MES','ANIO','PUERTO_PON','PUERTO'],values=['ALARMA','SDG'],aggfunc={'ALARMA':'count','SDG':'sum'}).reset_index()

    print(tdp)

    total = pd.concat([total,tdp],ignore_index=True)

total = pd.pivot_table(total,index=['PERIODO','MES','ANIO','PUERTO_PON','PUERTO'],values=['ALARMA','SDG'],aggfunc={'ALARMA':'sum','SDG':'sum'}).reset_index()
total['OLT'] = total['PUERTO_PON'].str.rsplit(pat='_',n=1,expand=True)[0]

total = total.merge(lista[['PUERTO_PON','ZONA','FECHA_TRABAJO','FASE TRABAJO']],how='left')

total['MES_N'] = (((total['ANIO']-2025)*12)+total['MES']) - (((pd.to_datetime(total['FECHA_TRABAJO']).dt.year - 2025)*12)+pd.to_datetime(total['FECHA_TRABAJO']).dt.month)

######

total.to_csv(r"D:/Downloads/evo_ratio_alarmas_puerto_total_mensual_n_1.csv",index=False)

print(total)